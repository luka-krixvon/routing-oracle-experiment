# Combined supplementary evidence with the post-review human check

This single-file wrapper accompanies the 27-page revised candidate of
*What Does a Routing Oracle Measure Under Stochastic Decoding? Coupling,
Scorer Choice, and Single-Commit Ceilings*.

It preserves the original submission archive and the earlier numerical
addendum **byte for byte**, and adds an anonymous aggregate record and the
existing judgment rules for Appendix D. Packaging performs no new experiment,
scoring, human annotation, or adjudication. This is a local candidate, not an
upload or acceptance record.

This delivery version updates only the outer documentation and manifest to match
the manuscript's contribution-clarification edit. The evidence payloads are unchanged.

## Contents and locations in the manuscript

| Member | Evidence scope |
|---|---|
| `original/routing-oracle-supplement.zip` | Original frozen tensors, numerical contract, canonical Run-A results, and member hashes. |
| `revision/routing-oracle-revision-addendum-20260922.zip` | Existing querywise/descriptive outputs for Section 6.1 and Appendix B.2, and historical-archive policy illustration for Appendix C. |
| `human-audit/aggregate_summary.json` | Existing per-benchmark/per-stratum human-check counts underlying Appendix D and Table 15. |
| `human-audit/README.md` | Definitions, consensus rule, closure timing, privacy scope, and limits of the aggregate export. |
| `human-audit/RUBRIC.md` | Unchanged rules supplied in the human packets. This is the historical rule version, not an instruction to resume annotation. |
| `revision_manifest.json` | SHA-256, size, and role of every other member, including this README. |

The two inner archives have SHA-256 values:

- Original: `76e3fdf2b9bc6bc5e61c8d865a6f30fd29885dc36921fbf68fd8bd7bdfe08919`.
- Numerical addendum: `03f5664f17b830e03145152443ce113277b0d67390786b92827c19c017547d58`.

The corresponding manuscript PDF has SHA-256
`50d21f7f60b9743a6dfd2799ea47e92920a58449fc6937a7e40b69919eeff8c5`.
The PDF belongs in the separate manuscript field and is not embedded here.

## How to read the preserved versions

Extract the outer wrapper, then extract the two inner ZIPs into separate
directories. Do not overlay them or rename their internal members. Each
inner manifest retains its original relative-path meaning.

**Status precedence:** statements about human validation being pending or
human evidence being absent in earlier inner documentation describe those
earlier versions only. They are not the status of this combined wrapper.
The new `human-audit/` directory supplies the later, limited check; it does
not retroactively modify the original evidence or certify all scorers.
Similarly, the historical rubric's wording about when to start or future
annotation is preserved for provenance, not an active assignment. The human
check is closed with undetermined cases; no follow-up was collected.

The numerical addendum's original-bundle dependency is supplied alongside it
in this wrapper. The original absence-of-policy-output invariant applies to
Run-A only, not to the later `router/` evidence inside the addendum.

## Human-check interpretation

Three contributors supplied two initial judgments per response across 30
GSM8K and 30 GPQA-Diamond cells. Each benchmark includes 15 cells from each
original frozen-v2 score side. Matching definite judgments covered 26/30
GSM8K and 11/30 GPQA-Diamond cells; all these consensuses agreed with frozen
v2. The other 4 and 19 cells remain undetermined and are reported, not dropped.

Planned follow-up was cancelled after the initial agreement summary had been
seen, but before comparison with automated scores. The closure rule and
analysis consensus were locked before that comparison. The check is partial,
reference-based evidence, not 100% scorer accuracy, a pristine development
holdout, or validation of all models, scorer channels, or benchmark gold.

The aggregate includes fixed-sample completion bounds retained from the
analysis. They are not confidence intervals or archive/population estimates
and do not account for shared human errors. The paper reports counts and
conditional denominators, rather than presenting these upper endpoints as
accuracy claims.

## Evidence and privacy boundaries

- The policy illustration reuses historically inspected data. Stage-level
  exclusion of EVAL scores does not establish historical independence or
  new-data generalization.
- No original scores, analysis results, or human judgments are changed by
  this wrapper. Later human agreement does not remove scorer-development
  output exposure.
- No names, invitations, consent records, individual human explanations,
  case-level human returns, or raw benchmark questions/responses are newly
  released. The new human material is limited to aggregates and rules.
- Source hashes identify retained records but do not independently certify
  participant identity, independence, expertise, or adherence to blinding.
  The aggregate alone cannot reproduce case-level judgments.
- No analysis source or runtime is newly supplied. Self-contained means the
  original and revision numerical evidence are delivered together, not that
  every historical process or human decision is publicly replayable.

Do not overwrite this wrapper or either inner ZIP. Any later changes require
a new delivery version and manifest.
