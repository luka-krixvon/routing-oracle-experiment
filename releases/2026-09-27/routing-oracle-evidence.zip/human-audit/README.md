# Aggregate record for the post-review human check

`aggregate_summary.json` is an allowlisted copy of the already computed VM
summary for the reference-based check in Appendix D, Table 15. This export
does not recompute labels, rescore responses, or add human judgments.

The sample consists of 30 GSM8K and 30 GPQA-Diamond archived response cells,
15 per original frozen-v2 score side for each benchmark. Three contributors
supplied 40 initial judgments each, with two initial judgments per cell.
Only matching definite judgments form an analysis consensus; all other
pairs remain undetermined and are retained. Planned follow-up was cancelled
after inspection of the initial agreement summary, but the closure rule and
consensus record were locked before comparison with the automated scores.

For each benchmark and stratum, N is the full sample count, M the definite
consensus matching the scorer, D the definite consensus differing from the
scorer, and U the undetermined count. The stored conditional agreement applies
only to the M+D cases, not all N cases. An initial CORRECT/INCORRECT pair
belongs to U, not D. All cases and original judgments were retained.

The source also stores fixed-sample completion bounds. They assign every
undetermined case a mismatch or a match; they are not confidence intervals,
archive/population accuracy estimates, or protection against shared human
error. The paper reports counts and conditional denominators rather than
promoting the upper endpoint to an accuracy claim.

The source hashes bind this extract to retained private records. No question,
raw response, individual explanation, name, email, or participant identifier
is included here. Consequently this aggregate export alone cannot reproduce
the judgments or independently establish participant identity, independence,
expertise, or adherence to blinding. It is not a replacement for those records.

The original score tensors and scientific results are unchanged. This later
check does not remove output exposure during scorer development, validate
MATH-500 or other scorer channels, or establish archive-wide correctness.

This directory is prepared locally, not yet included in an uploaded
supplementary package. Existing supplement ZIPs must not be overwritten.
