# Human response evaluation rules

Version: 2026-09-23-candidate-1. The author adopted these rules for preparing the candidate packets. Begin only when the coordinator confirms the agreed schedule and asks you to start. Please raise any rule questions before opening your study items; there is no target agreement rate.

## The judgment

Judge the final answer explicitly supported by the raw response against the official reference for that question. Judge answer meaning, not writing quality or the behavior of an automated extractor. This is not a full re-solution or proof audit. If a substantive question about the reference or scientific content prevents a defensible judgment, leave it unresolved.

| Label | Use when |
|---|---|
| `CORRECT` | The supported final answer clearly matches the reference under these rules. |
| `INCORRECT` | The supported final answer clearly fails to match, or the complete response provides no answer. |
| `UNRESOLVED` | Missing information, conflicting answers, substantive ambiguity, expertise limits, or an uncovered case prevents a clear judgment. |

For future annotation, record the exact final-answer span and a short reason. Where no answer span exists, leave the span empty and explain why. Do not invent a quotation or choose an answer just because it matches the reference.

## Rules shared by both benchmarks

- A later answer supersedes an earlier one only when the response clearly withdraws or corrects it. Conflicting answers without a clear choice are `UNRESOLVED`.
- A complete record whose response refuses, only restates the question, or otherwise supplies no answer is `INCORRECT`. Missing raw data, uncertain record completeness, or an unclear question/reference pairing is `UNRESOLVED`: a data problem is not evidence of a wrong model answer.
- Substantive ambiguity in the question or official reference is `UNRESOLVED`. Describe the concern; do not replace the reference yourself.
- Preserve the raw text. Report accidental exposure to model clues, scoring information, or another annotator's unlocked judgment.
- In formal work, do not use AI, external automated scorers, or another annotator's answers to make your judgments. Do not seek hidden scoring information. Report uncovered cases to the coordinator; do not silently change the rules while annotating.

## GSM8K: numerical answers

- Accept mathematical equivalence in the quantities and units requested, not just identical text. Standard thousands separators, fractions, and equivalent finite decimals are acceptable.
- Accept rounding only where the question permits approximation or specifies precision. Do not introduce an extra numerical tolerance.
- Units must match or be clearly convertible. If a response omits the unit and the question uniquely specifies it, interpret the answer in that unit. If unit ambiguity changes the numerical meaning and cannot be resolved, use `UNRESOLVED`.
- Numbers used in intermediate calculations are not automatically competing final answers; identify the explicit conclusion.

## GPQA-Diamond: option answers

- Use the actual option order in the original question and its verified reference mapping. A letter from a different ordering cannot be compared directly.
- An unambiguous option letter or quotation of an option's content can express the answer.
- A letter that conflicts with its quoted option text, or competing answers without a clear choice, is `UNRESOLVED`, unless explicitly withdrawn and corrected later. A complete response providing no answer follows the shared `INCORRECT` rule.
- If the reference or scientific statement appears substantively questionable, or the item exceeds your expertise, use `UNRESOLVED` and explain. Request review by someone with the relevant expertise; confidence alone is not a substitute for a defensible judgment.

An unresolved judgment is acceptable. There is no target agreement percentage or pass threshold, and disagreement does not by itself establish that either the automated scorer or the human reviewer is wrong.
